import java.sql.*;

import javax.swing.*;


public class dbCon {
	Connection conn =null;
	
	public static Connection dbConector(){
		try{
			Class.forName("org.sqlite.JDBC");
			Connection conn=DriverManager.getConnection("jdbc:sqlite:prop/VAULTlogin.sqlite");
			 
			/*String query="Insert Into MYINFO(username, password, notes) values (?,?,?)";
			PreparedStatement pst=conn.prepareStatement(query) ;
			pst.setString(1, "dddd");
			pst.setString(2, "dddd");
			pst.setString(3, "dddd");
			pst.executeQuery();*/
			/*String query="SELECT * FROM LogIn_directory";
			Statement stmt  = conn.createStatement();
			System.out.println("----------------> "+query);
			ResultSet rs=stmt.executeQuery(query);
			
			while(rs.next()){
				System.out.println("you are here--------> "+rs);
			}
			
			JOptionPane.showMessageDialog(null, "Connection Extablished");
			conn.close();*/
			//JOptionPane.showMessageDialog(null, "Connection Extablished");
			
			return conn;
		}
		catch(Exception e){
			JOptionPane.showMessageDialog(null, e);
		}
		return null;
		
	}

}
