import java.awt.BorderLayout;
import java.sql.*;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;

import java.awt.Color;
import java.awt.Font;
import java.awt.SystemColor;

import javax.swing.JButton;
import java.sql.Connection;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;


public class ExistingUser extends JFrame {

	private JPanel contentPane;
	private JTextField userId;
	
	private JPasswordField passwordField_1;

	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ExistingUser frame = new ExistingUser();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
*/
	/**
	 * Create the frame.
	 */
	Connection conec=null;
	
	public ExistingUser() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("prop/logo-login.png"));
		conec=dbCon.dbConector();
		setForeground(SystemColor.desktop);
		setTitle("v a u l t");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(135, 206, 235));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		userId = new JTextField();
		userId.setBounds(254, 82, 149, 20);
		contentPane.add(userId);
		userId.setColumns(10);
		
		passwordField_1 = new JPasswordField();
		passwordField_1.setBounds(254, 124, 149, 20);
		contentPane.add(passwordField_1);
		
		JLabel lblUSE = new JLabel("u s e r  I D");
		lblUSE.setBounds(117, 88, 98, 14);
		contentPane.add(lblUSE);
		
		JLabel lblPAS = new JLabel("p a s s CODE");
		lblPAS.setBounds(117, 130, 86, 14);
		contentPane.add(lblPAS);
		
		JLabel lblVAU = new JLabel("v a u l t | L o g In");
		lblVAU.setForeground(SystemColor.menuText);
		lblVAU.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblVAU.setBounds(133, 11, 149, 31);
		contentPane.add(lblVAU);
		
		JLabel lblNewLabel = new JLabel("p r o d u c t  by  M R");
		lblNewLabel.setBounds(300, 233, 134, 28);
		contentPane.add(lblNewLabel);
		
		JButton btnSIG = new JButton("s i g n  In");
		btnSIG.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try{
					String query="SELECT * FROM LogIn_directory WHERE username=? and password=? ";
					System.out.println("----------------> "+query);
					PreparedStatement pst=conec.prepareStatement(query) ;
					pst.setString(1, userId.getText());
					pst.setString(2, passwordField_1.getText());
					ResultSet rs=pst.executeQuery();
					int count=0;
					while(rs.next()){
						count=count+1;
					}
					
					if(count==1){
						
						JOptionPane.showMessageDialog(null, "User Authentication Done !");
						CreateDataFrame DataFrame=new CreateDataFrame();
						DataFrame.setVisible(true);
					}
					else{
						JOptionPane.showMessageDialog(null, "Authorizaton Denied !");
					    System.exit(ABORT);
					}
				}
				catch(Exception e1){
					JOptionPane.showMessageDialog(null, "Error Code: 3100     Error Message : "+e1);
				}
				finally{
					try{
						conec.close();
					}
					catch(Exception e2){
						JOptionPane.showMessageDialog(null, "Error Code: 3101     Error Message : "+e2);
					}
				}
			}
		});
		btnSIG.setToolTipText("");
		btnSIG.setBounds(180, 176, 89, 23);
		contentPane.add(btnSIG);
		
		
		
		
	}
}
