import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;

import java.awt.Font;
import java.awt.SystemColor;

import javax.swing.JButton;
import javax.swing.JTable;

import net.proteanit.sql.DbUtils;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JTabbedPane;
import javax.swing.JLayeredPane;
import javax.swing.JInternalFrame;
import java.awt.Toolkit;


public class CreateDataFrame extends JFrame {

	private JPanel contentPane;


	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CreateDataFrame frame = new CreateDataFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}*/

	/**
	 * Create the frame.
	 */
	Connection connect=null;
	private JTextField textField;
	private JTable table;
	public CreateDataFrame() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("prop/logo-login.png"));
		connect=dbCon.dbConector();
		setTitle("v a u l t");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 713, 453);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(102, 204, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Get Your All Personal Information In One Click");
		lblNewLabel.setFont(new Font("Lucida Console", Font.PLAIN, 14));
		lblNewLabel.setBounds(143, 11, 404, 14);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("Load Information");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try{
				String query="SELECT * FROM MYINFO";
				Statement stmt=connect.createStatement();
				ResultSet rs=stmt.executeQuery(query);
				table.setModel(DbUtils.resultSetToTableModel(rs));
				
				}
				catch(Exception e3){
					JOptionPane.showMessageDialog(null, "Error Code: 3102     Error Message : "+e3);
					
				}
				finally{
					try{
						connect.close();
					}
					catch(Exception e4){
						JOptionPane.showMessageDialog(null, "Error Code: 3103     Error Message : "+e4);
					}
				}
				
			}
		});
		btnNewButton.setBackground(new Color(0, 102, 153));
		btnNewButton.setBounds(361, 34, 154, 23);
		contentPane.add(btnNewButton);
		
		JButton btnInsertInformation = new JButton("Insert Information");
		btnInsertInformation.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				InserDataFrame DataFrame=new InserDataFrame();
				DataFrame.setVisible(true);
			
			}
		});
		btnInsertInformation.setBackground(new Color(0, 102, 153));
		btnInsertInformation.setBounds(143, 36, 154, 23);
		contentPane.add(btnInsertInformation);
		
		table = new JTable();
		table.setBackground(new Color(100, 149, 237));
		table.setBounds(35, 104, 641, 283);
		contentPane.add(table);
		
		
		
		

}
}
