import java.awt.EventQueue;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.SystemColor;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.awt.Font;
import java.awt.Toolkit;


public class LoginFrameMain {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginFrameMain window = new LoginFrameMain();
					
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 * @throws IOException 
	 */
	Connection conection=null;
	public LoginFrameMain() throws IOException {
		initialize();
		//conection=dbCon.dbConector();
		
	}

	/**
	 * Initialize the contents of the frame.
	 * @throws IOException 
	 */
	private void initialize() throws IOException {
		
		frame = new JFrame("v a u l t");
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage("prop/logo-login.png"));
		frame.getContentPane().setFont(new Font("Lucida Console", Font.PLAIN, 14));
		frame.getContentPane().setBackground(new Color(220, 20, 60));
		//frame.setContentPane(new JLabel(new ImageIcon(ImageIO.read(new File("src/LogIn3.png")))));
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		
		JButton btnNewUser = new JButton("New User");
		btnNewUser.setForeground(new Color(30, 144, 255));
		btnNewUser.setFont(new Font("Lucida Console", Font.PLAIN, 13));
		btnNewUser.setBackground(new Color(255, 255, 153));
		
		btnNewUser.setBounds(217, 95, 176, 23);
		frame.getContentPane().add(btnNewUser);
		
		JButton btnExistingUser = new JButton("Existing User");
		btnExistingUser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				ExistingUser newUser=new ExistingUser();
				newUser.setVisible(true);
			}
		});
		btnExistingUser.setForeground(new Color(0, 191, 255));
		btnExistingUser.setFont(new Font("DialogInput", Font.PLAIN, 13));
		btnExistingUser.setBackground(new Color(255, 255, 153));
		btnExistingUser.setBounds(217, 141, 176, 23);
		frame.getContentPane().add(btnExistingUser);
		
		JLabel lblNewLabel = new JLabel("w e l c o m e\r\n ");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel.setBounds(37, 82, 134, 36);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblTO = new JLabel("t o");
		lblTO.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblTO.setBounds(37, 118, 46, 14);
		frame.getContentPane().add(lblTO);
		
		JLabel lblVAU = new JLabel("v a u l t");
		lblVAU.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblVAU.setBounds(37, 144, 113, 14);
		frame.getContentPane().add(lblVAU);
	}
}
