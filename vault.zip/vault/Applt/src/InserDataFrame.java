import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.Toolkit;
import java.awt.GridLayout;

import javax.swing.JLabel;

import java.awt.Font;
import java.awt.Color;

import javax.swing.JTextField;
import javax.swing.JButton;

import net.proteanit.sql.DbUtils;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;


public class InserDataFrame extends JFrame {
	private JTextField userName;
	private JTextField password;
	private JTextField notes;

	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					InserDataFrame frame = new InserDataFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}*/

	/**
	 * Create the frame.
	 */
	Connection connect=null;
	public InserDataFrame() {
		connect=dbCon.dbConector();
		getContentPane().setBackground(new Color(135, 206, 250));
		setIconImage(Toolkit.getDefaultToolkit().getImage("prop/logo-login.png"));
		setTitle("v a u l t");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 702, 432);
		getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("User Name");
		lblNewLabel.setFont(new Font("Segoe UI Symbol", Font.PLAIN, 14));
		lblNewLabel.setBounds(53, 122, 104, 28);
		getContentPane().add(lblNewLabel);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setFont(new Font("Segoe UI Symbol", Font.PLAIN, 14));
		lblPassword.setBounds(53, 197, 104, 14);
		getContentPane().add(lblPassword);
		
		JLabel lblNotes = new JLabel("Notes");
		lblNotes.setFont(new Font("Segoe UI Symbol", Font.PLAIN, 14));
		lblNotes.setBounds(55, 260, 63, 14);
		getContentPane().add(lblNotes);
		
		userName = new JTextField();
		userName.setBounds(181, 116, 318, 34);
		getContentPane().add(userName);
		userName.setColumns(10);
		
		password = new JTextField();
		password.setBounds(181, 177, 318, 34);
		getContentPane().add(password);
		password.setColumns(10);
		
		notes = new JTextField();
		notes.setBounds(181, 240, 318, 34);
		getContentPane().add(notes);
		notes.setColumns(10);
		
		JLabel lblKeepYourPersonals = new JLabel("Keep Your Personals Personal");
		lblKeepYourPersonals.setFont(new Font("Courier New", Font.BOLD, 16));
		lblKeepYourPersonals.setBounds(182, 0, 361, 42);
		getContentPane().add(lblKeepYourPersonals);
		
		JButton btnNewButton = new JButton("Insert");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try{
					
					Statement statement = connect.createStatement();
					 
		             statement.executeUpdate("Insert Into MYINFO(username, password, notes) values ('"+userName.getText()+"','"+password.getText()+"','"+notes.getText()+"')");
					JOptionPane.showMessageDialog(null, " Record Inserted ");
					System.exit(ABORT);
					
					}
					catch(Exception e3){
						JOptionPane.showMessageDialog(null, "Error Code: 3104     Error Message : "+e3);
						
					}
					finally{
						try{
							connect.close();
						}
						catch(Exception e4){
							JOptionPane.showMessageDialog(null, "Error Code: 3105     Error Message : "+e4);
						}
					}
			}
		});
		btnNewButton.setBackground(new Color(100, 149, 237));
		btnNewButton.setBounds(267, 336, 89, 23);
		getContentPane().add(btnNewButton);
		
	}

}
